package gui;

import model.*;
import service.AttendanceService;
import service.AuthService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;

public class AttendancePanel extends JPanel {
    private final AttendanceService service=new AttendanceService();
    private final DefaultTableModel model=new DefaultTableModel(new Object[]{"ID","Student Reg No","Student Name","Course Code","Course Name","Component","Session","Date","Present"},0){
        public boolean isCellEditable(int r,int c){return false;}
    };
    public AttendancePanel(){
        super(new BorderLayout(8,8)); add(new JLabel("Attendance Management — Technical Officer"),BorderLayout.NORTH);
        JTable table=new JTable(model); add(new JScrollPane(table),BorderLayout.CENTER);
        JPanel buttons=new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton add=new JButton("Add / Update"), delete=new JButton("Delete Selected"), refresh=new JButton("Refresh");
        buttons.add(add);buttons.add(delete);buttons.add(refresh);add(buttons,BorderLayout.SOUTH);
        boolean canEdit=AuthService.hasRole("TECHNICAL_OFFICER")||AuthService.hasRole("ADMIN");
        add.setEnabled(canEdit);delete.setEnabled(canEdit);
        add.addActionListener(e->addAttendance());delete.addActionListener(e->{int row=table.getSelectedRow();if(row<0)return;try{service.delete((int)model.getValueAt(table.convertRowIndexToModel(row),0));load();}catch(Exception ex){error(ex);}});
        refresh.addActionListener(e->load());load();
    }
    private void addAttendance(){
        JTextField reg=new JTextField(),code=new JTextField(),session=new JTextField("1"),date=new JTextField(LocalDate.now().toString());
        JComboBox<ComponentType> component=new JComboBox<>(ComponentType.values());JCheckBox present=new JCheckBox("Present",true);
        JPanel p=new JPanel(new GridLayout(0,2,5,5));p.add(new JLabel("Student registration no"));p.add(reg);p.add(new JLabel("Course code"));p.add(code);p.add(new JLabel("Component"));p.add(component);p.add(new JLabel("Session (1-15)"));p.add(session);p.add(new JLabel("Date (YYYY-MM-DD)"));p.add(date);p.add(new JLabel("Attendance"));p.add(present);
        if(JOptionPane.showConfirmDialog(this,p,"Attendance Entry",JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION)return;
        try{service.save(new AttendanceRecord(0,reg.getText().trim(),"",code.getText().trim(),"",(ComponentType)component.getSelectedItem(),Integer.parseInt(session.getText().trim()),LocalDate.parse(date.getText().trim()),present.isSelected()));load();}
        catch(Exception ex){error(ex);}
    }
    private void load(){try{model.setRowCount(0);for(AttendanceRecord r:service.getAll())model.addRow(new Object[]{r.getRecordId(),r.getStudentRegNo(),r.getStudentName(),r.getCourseCode(),r.getCourseName(),r.getComponentType(),r.getSessionNumber(),r.getSessionDate(),r.isPresent()});}catch(Exception ex){error(ex);}}
    private void error(Exception ex){JOptionPane.showMessageDialog(this,ex.getMessage(),"Attendance",JOptionPane.ERROR_MESSAGE);}
}
