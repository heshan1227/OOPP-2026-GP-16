package gui;

import model.*;
import service.MedicalService;
import service.AuthService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;

public class MedicalPanel extends JPanel {
    private final MedicalService service=new MedicalService();
    private final DefaultTableModel model=new DefaultTableModel(new Object[]{"ID","Student","Name","Course","Component","Session","Absent Date","Reference","Reason","Submitted","Status","Reviewed By"},0){public boolean isCellEditable(int r,int c){return false;}};
    public MedicalPanel(){
        super(new BorderLayout(8,8));add(new JLabel("Medical Management — Technical Officer"),BorderLayout.NORTH);
        JTable table=new JTable(model);add(new JScrollPane(table),BorderLayout.CENTER);
        JPanel actions=new JPanel(new FlowLayout(FlowLayout.LEFT));JButton submit=new JButton("Record Medical"),approve=new JButton("Approve"),reject=new JButton("Reject"),refresh=new JButton("Refresh");
        actions.add(submit);actions.add(approve);actions.add(reject);actions.add(refresh);add(actions,BorderLayout.SOUTH);
        boolean canReview=AuthService.hasRole("TECHNICAL_OFFICER")||AuthService.hasRole("ADMIN");
        submit.setEnabled(canReview);approve.setEnabled(canReview);reject.setEnabled(canReview);
        submit.addActionListener(e->submit());approve.addActionListener(e->review(table,MedicalStatus.APPROVED));reject.addActionListener(e->review(table,MedicalStatus.REJECTED));refresh.addActionListener(e->load());load();
    }
    private void submit(){
        JTextField reg=new JTextField(),course=new JTextField(),session=new JTextField("1"),absent=new JTextField(LocalDate.now().toString()),ref=new JTextField(),reason=new JTextField(),path=new JTextField();
        JComboBox<ComponentType> comp=new JComboBox<>(ComponentType.values());JPanel p=new JPanel(new GridLayout(0,2,5,5));
        add(p,"Student registration no",reg);add(p,"Course code",course);add(p,"Component",comp);add(p,"Session (1-15)",session);add(p,"Absent date YYYY-MM-DD",absent);add(p,"Medical reference",ref);add(p,"Reason",reason);add(p,"Certificate path (optional)",path);
        if(JOptionPane.showConfirmDialog(this,p,"Record Medical",JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION)return;
        try{service.submit(new MedicalRecord(0,reg.getText().trim(),"",course.getText().trim(),(ComponentType)comp.getSelectedItem(),Integer.parseInt(session.getText().trim()),LocalDate.parse(absent.getText().trim()),ref.getText().trim(),reason.getText().trim(),LocalDate.now(),MedicalStatus.PENDING,null,path.getText().trim()));load();}
        catch(Exception ex){error(ex);}
    }
    private void review(JTable table,MedicalStatus status){int row=table.getSelectedRow();if(row<0){error(new IllegalArgumentException("Select a medical record first."));return;}try{service.review((int)model.getValueAt(table.convertRowIndexToModel(row),0),status,AuthService.getCurrentUser()==null?"Technical Officer":AuthService.getCurrentUser().getName());load();}catch(Exception ex){error(ex);}}
    private void load(){try{model.setRowCount(0);for(MedicalRecord r:service.getAll())model.addRow(new Object[]{r.getMedicalId(),r.getStudentRegNo(),r.getStudentName(),r.getCourseCode(),r.getComponentType(),r.getSessionNumber(),r.getAbsentDate(),r.getReferenceNo(),r.getReason(),r.getSubmissionDate(),r.getStatus(),r.getReviewedBy()});}catch(Exception ex){error(ex);}}
    private void add(JPanel p,String label,JComponent c){p.add(new JLabel(label));p.add(c);}
    private void error(Exception ex){JOptionPane.showMessageDialog(this,ex.getMessage(),"Medical Management",JOptionPane.ERROR_MESSAGE);}
}
