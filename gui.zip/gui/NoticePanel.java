package gui;

import model.Notice;
import service.NoticeService;
import service.AuthService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;

public class NoticePanel extends JPanel {
    private final NoticeService service=new NoticeService();
    private final DefaultTableModel model=new DefaultTableModel(new Object[]{"ID","Title","Content","Published By","Published At","Target Role","Important"},0){public boolean isCellEditable(int r,int c){return false;}};
    public NoticePanel(){
        super(new BorderLayout(8,8));add(new JLabel("Notice Board / Notice Management"),BorderLayout.NORTH);
        JTable table=new JTable(model);add(new JScrollPane(table),BorderLayout.CENTER);
        JPanel actions=new JPanel(new FlowLayout(FlowLayout.LEFT));JButton add=new JButton("Publish Notice"),delete=new JButton("Delete Selected"),refresh=new JButton("Refresh");
        actions.add(add);actions.add(delete);actions.add(refresh);add(actions,BorderLayout.SOUTH);
        boolean admin=AuthService.hasRole("ADMIN");add.setEnabled(admin);delete.setEnabled(admin);
        add.addActionListener(e->publish());delete.addActionListener(e->{int row=table.getSelectedRow();if(row<0)return;try{service.delete((int)model.getValueAt(table.convertRowIndexToModel(row),0));load();}catch(Exception ex){error(ex);}});
        refresh.addActionListener(e->load());load();
    }
    private void publish(){
        JTextField title=new JTextField(),content=new JTextField();JComboBox<String> role=new JComboBox<>(new String[]{"ALL","ADMIN","LECTURER","TECHNICAL_OFFICER","UNDERGRADUATE"});JCheckBox important=new JCheckBox("Important");
        JPanel p=new JPanel(new GridLayout(0,2,5,5));p.add(new JLabel("Title"));p.add(title);p.add(new JLabel("Content"));p.add(content);p.add(new JLabel("Target role"));p.add(role);p.add(new JLabel("Priority"));p.add(important);
        if(JOptionPane.showConfirmDialog(this,p,"Publish Notice",JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION)return;
        try{int userId=AuthService.getCurrentUser()==null?0:AuthService.getCurrentUser().getUserId();service.publish(new Notice(0,title.getText().trim(),content.getText().trim(),null,LocalDateTime.now(),(String)role.getSelectedItem(),important.isSelected()),userId);load();}
        catch(Exception ex){error(ex);}
    }
    private void load(){try{model.setRowCount(0);String role=AuthService.getCurrentUser()==null?"UNDERGRADUATE":AuthService.getCurrentUser().getRole();for(Notice n:service.getVisible(role))model.addRow(new Object[]{n.getNoticeId(),n.getTitle(),n.getContent(),n.getPublishedBy(),n.getPublishedDate(),n.getTargetRole()==null?"ALL":n.getTargetRole(),n.isImportant()});}catch(Exception ex){error(ex);}}
    private void error(Exception ex){JOptionPane.showMessageDialog(this,ex.getMessage(),"Notice Management",JOptionPane.ERROR_MESSAGE);}
}
