package gui;

import model.TimetableEntry;
import service.TimetableService;
import service.AuthService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class TimetablePanel extends JPanel {
    private final TimetableService service=new TimetableService();
    private final DefaultTableModel model=new DefaultTableModel(new Object[]{"ID","Day","Start","End","Course Code","Course Name","Component","Venue","Lecturer","Department","Batch","Period"},0){public boolean isCellEditable(int r,int c){return false;}};
    public TimetablePanel(){
        super(new BorderLayout(8,8));add(new JLabel("Academic Timetable"),BorderLayout.NORTH);
        JTable table=new JTable(model);add(new JScrollPane(table),BorderLayout.CENTER);
        JPanel actions=new JPanel(new FlowLayout(FlowLayout.LEFT));JButton add=new JButton("Add Timetable Entry"),edit=new JButton("Edit Selected"),delete=new JButton("Delete Selected"),refresh=new JButton("Refresh");actions.add(add);actions.add(edit);actions.add(delete);actions.add(refresh);add(actions,BorderLayout.SOUTH);
        add.setEnabled(AuthService.hasRole("ADMIN"));edit.setEnabled(AuthService.hasRole("ADMIN"));delete.setEnabled(AuthService.hasRole("ADMIN"));add.addActionListener(e->editEntry(null));edit.addActionListener(e->{int row=table.getSelectedRow();if(row<0){error(new IllegalArgumentException("Select a timetable entry first."));return;}editEntry(table.convertRowIndexToModel(row));});delete.addActionListener(e->{int row=table.getSelectedRow();if(row<0)return;try{service.delete((int)model.getValueAt(table.convertRowIndexToModel(row),0));load();}catch(Exception ex){error(ex);}});
        refresh.addActionListener(e->load());load();
    }
    private void editEntry(Integer row){
        boolean editing=row!=null; int entryId=editing?(int)model.getValueAt(row,0):0;
        JTextField courseId=new JTextField(),batchId=new JTextField(),periodId=new JTextField(),lecturerId=new JTextField();
        JComboBox<String> component=new JComboBox<>(new String[]{"THEORY","PRACTICAL"});
        JComboBox<String> day=new JComboBox<>(new String[]{"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"});
        JTextField start=new JTextField(editing?String.valueOf(model.getValueAt(row,2)):"08:00"),end=new JTextField(editing?String.valueOf(model.getValueAt(row,3)):"10:00"),venue=new JTextField(editing?String.valueOf(model.getValueAt(row,7)):""),department=new JTextField(editing?String.valueOf(model.getValueAt(row,9)):"");
        if(editing){component.setSelectedItem(model.getValueAt(row,6));day.setSelectedItem(model.getValueAt(row,1));}
        JPanel p=new JPanel(new GridLayout(0,2,5,5));
        addField(p,"Course ID (TG2138)",courseId);addField(p,"Batch ID (optional)",batchId);addField(p,"Academic Period ID (optional)",periodId);addField(p,"Lecturer User ID (optional)",lecturerId);addField(p,"Component",component);addField(p,"Day",day);addField(p,"Start time (HH:mm)",start);addField(p,"End time (HH:mm)",end);addField(p,"Venue",venue);addField(p,"Department",department);
        if(JOptionPane.showConfirmDialog(this,p,editing?"Edit Timetable Entry":"Add Timetable Entry",JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION)return;
        try{
            Integer bid=optionalId(batchId.getText()),pid=optionalId(periodId.getText()),lid=optionalId(lecturerId.getText());
            model.TimetableEntry entry=new model.TimetableEntry(entryId,"","",(String)component.getSelectedItem(),(String)day.getSelectedItem(),java.time.LocalTime.parse(start.getText().trim()),java.time.LocalTime.parse(end.getText().trim()),venue.getText().trim(),"",department.getText().trim(),"","");
            int cid=Integer.parseInt(courseId.getText().trim());if(editing)service.update(entry,cid,bid,pid,lid);else service.add(entry,cid,bid,pid,lid);load();
        }catch(Exception ex){error(ex);}
    }
    private Integer optionalId(String value){return value==null||value.trim().isEmpty()?null:Integer.valueOf(value.trim());}
    private void addField(JPanel panel,String label,JComponent field){panel.add(new JLabel(label));panel.add(field);}
    private void load(){try{model.setRowCount(0);for(TimetableEntry t:service.getAll())model.addRow(new Object[]{t.getTimetableId(),t.getDayOfWeek(),t.getStartTime(),t.getEndTime(),t.getCourseCode(),t.getCourseName(),t.getComponentType(),t.getVenue(),t.getLecturerName(),t.getDepartment(),t.getBatchName(),t.getAcademicPeriod()});}catch(Exception ex){error(ex);}}
    private void error(Exception ex){JOptionPane.showMessageDialog(this,ex.getMessage(),"Timetable",JOptionPane.ERROR_MESSAGE);}
}
