import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DivisionCalculator {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(400, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel lblNum1 = new JLabel("Number 1 :");
        lblNum1.setBounds(30, 30, 80, 25);
        frame.add(lblNum1);

        JTextField txtNum1 = new JTextField();
        txtNum1.setBounds(110, 30, 80, 25);
        frame.add(txtNum1);

        JLabel lblNum2 = new JLabel("Number 2 :");
        lblNum2.setBounds(30, 70, 80, 25);
        frame.add(lblNum2);

        JTextField txtNum2 = new JTextField();
        txtNum2.setBounds(110, 70, 80, 25);
        frame.add(txtNum2);

        JLabel lblResultTitle = new JLabel("Result");
        lblResultTitle.setBounds(220, 30, 80, 25);
        frame.add(lblResultTitle);

        JLabel lblResultValue = new JLabel("");
        lblResultValue.setBounds(220, 60, 80, 25);
        frame.add(lblResultValue);

        JButton btnDivide = new JButton("Divide");
        btnDivide.setBounds(60, 120, 100, 30);
        frame.add(btnDivide);

        btnDivide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Parse the input numbers
                    double num1 = Double.parseDouble(txtNum1.getText().trim());
                    double num2 = Double.parseDouble(txtNum2.getText().trim());

                    if (num2 == 0) {
                        lblResultValue.setText("");

                        JOptionPane.showMessageDialog(frame,
                                "You can't enter 0 for second number",
                                "Message",
                                JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        double result = num1 / num2;
                        lblResultValue.setText(String.valueOf(result));
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame,
                            "Please enter valid numeric values.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Center the frame on the screen and make it visible
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
