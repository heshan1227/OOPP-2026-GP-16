import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudentForm extends JFrame {

    private JTextField txtName, txtID, txtEmail, txtPhone, txtDOB, txtDept, txtCourse, txtGPA, txtAddress1, txtAddress2;
    private JRadioButton rbtnMale, rbtnFemale, rbtnOther;
    private JComboBox<String> cmbYear;
    private ButtonGroup genderGroup;

    public StudentForm() {
        setTitle("Student Information Form");
        setSize(500, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 10, 6, 10); // Spacing between rows

        txtName = new JTextField(20);
        txtID = new JTextField(20);
        txtEmail = new JTextField(20);
        txtPhone = new JTextField(20);
        txtDOB = new JTextField(10); // Format hint: [   /   /   ]
        txtDept = new JTextField(20);
        txtCourse = new JTextField(20);
        txtGPA = new JTextField(5);  // Format hint: [  .  ]
        txtAddress1 = new JTextField(20);
        txtAddress2 = new JTextField(20);
        rbtnMale = new JRadioButton("Male");
        rbtnFemale = new JRadioButton("Female");
        rbtnOther = new JRadioButton("Other");
        genderGroup = new ButtonGroup();
        genderGroup.add(rbtnMale);
        genderGroup.add(rbtnFemale);
        genderGroup.add(rbtnOther);

        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        genderPanel.add(rbtnMale);
        genderPanel.add(rbtnFemale);
        genderPanel.add(rbtnOther);

        String[] years = {"1", "2", "3", "4"};
        cmbYear = new JComboBox<>(years);

        int row = 0;
        addFormRow(mainPanel, gbc, "Student Name:", txtName, row++);
        addFormRow(mainPanel, gbc, "Student ID:", txtID, row++);
        addFormRow(mainPanel, gbc, "Email:", txtEmail, row++);
        addFormRow(mainPanel, gbc, "Phone Number:", txtPhone, row++);
        addFormRow(mainPanel, gbc, "Date of Birth:", txtDOB, row++);
        addFormRow(mainPanel, gbc, "Gender:", genderPanel, row++);
        addFormRow(mainPanel, gbc, "Department:", txtDept, row++);
        addFormRow(mainPanel, gbc, "Course:", txtCourse, row++);
        addFormRow(mainPanel, gbc, "Year of Study:", cmbYear, row++);
        addFormRow(mainPanel, gbc, "GPA:", txtGPA, row++);

        addFormRow(mainPanel, gbc, "Address:", txtAddress1, row++);
        addFormRow(mainPanel, gbc, "", txtAddress2, row++);

        JButton btnSubmit = new JButton("Submit");
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(20, 10, 10, 10); // Give button a bit extra top breathing space
        mainPanel.add(btnSubmit, gbc);

        btnSubmit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (txtName.getText().trim().isEmpty() ||
                        txtID.getText().trim().isEmpty() ||
                        txtEmail.getText().trim().isEmpty() ||
                        txtPhone.getText().trim().isEmpty() ||
                        txtDOB.getText().trim().isEmpty() ||
                        txtDept.getText().trim().isEmpty() ||
                        txtCourse.getText().trim().isEmpty() ||
                        txtGPA.getText().trim().isEmpty() ||
                        txtAddress1.getText().trim().isEmpty() ||
                        genderGroup.getSelection() == null) {

                    JOptionPane.showMessageDialog(StudentForm.this,
                            "You need to fill out all the data",
                            "Warning",
                            JOptionPane.WARNING_MESSAGE);
                } else {
                    String gender = rbtnMale.isSelected() ? "Male" : (rbtnFemale.isSelected() ? "Female" : "Other");
                    String fullAddress = txtAddress1.getText().trim() +
                            (txtAddress2.getText().trim().isEmpty() ? "" : ", " + txtAddress2.getText().trim());

                    String summaryMessage = String.format(
                            "Student Registered Successfully:\n\n" +
                                    "Name: %s\n" +
                                    "ID: %s\n" +
                                    "Email: %s\n" +
                                    "Phone: %s\n" +
                                    "DOB: %s\n" +
                                    "Gender: %s\n" +
                                    "Department: %s\n" +
                                    "Course: %s\n" +
                                    "Year of Study: %s\n" +
                                    "GPA: %s\n" +
                                    "Address: %s",
                            txtName.getText().trim(),
                            txtID.getText().trim(),
                            txtEmail.getText().trim(),
                            txtPhone.getText().trim(),
                            txtDOB.getText().trim(),
                            gender,
                            txtDept.getText().trim(),
                            txtCourse.getText().trim(),
                            cmbYear.getSelectedItem(),
                            txtGPA.getText().trim(),
                            fullAddress
                    );

                    JOptionPane.showMessageDialog(StudentForm.this,
                            summaryMessage,
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE);

                    txtName.setText("");
                    txtID.setText("");
                    txtEmail.setText("");
                    txtPhone.setText("");
                    txtDOB.setText("");
                    txtDept.setText("");
                    txtCourse.setText("");
                    txtGPA.setText("");
                    txtAddress1.setText("");
                    txtAddress2.setText("");

                    cmbYear.setSelectedIndex(0);
                    genderGroup.clearSelection();

                    txtName.requestFocus();
                }
            }
        });

        add(new JScrollPane(mainPanel));
    }

    private void addFormRow(JPanel panel, GridBagConstraints gbc, String labelText, Component comp, int row) {
        gbc.gridy = row;

        gbc.gridx = 0;
        gbc.gridwidth = 1;
        gbc.weightx = 0.3;
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.7;
        panel.add(comp, gbc);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StudentForm().setVisible(true);
        });
    }
}
