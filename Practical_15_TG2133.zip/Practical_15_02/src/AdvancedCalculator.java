import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class AdvancedCalculator extends JFrame implements ActionListener {

    private JTextField display;
    private List<String> calculationHistory = new ArrayList<>();
    private final String[] buttonLabels = {
            "C", "(", ")", "/",
            "7", "8", "9", "*",
            "4", "5", "6", "-",
            "1", "2", "3", "+",
            "0", ".", "=", "%"
    };

    public AdvancedCalculator() {
        setTitle("Calculator with History");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(350, 500);
        setLayout(new BorderLayout(10, 10));

        display = new JTextField("0");
        display.setFont(new Font("Arial", Font.PLAIN, 28));
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setEditable(false);
        display.setBackground(new Color(240, 240, 240));
        display.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(display, BorderLayout.CENTER);
        add(topPanel, BorderLayout.NORTH);

        JPanel gridPanel = new JPanel(new GridLayout(5, 4, 8, 8));
        gridPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        for (String label : buttonLabels) {
            JButton button = new JButton(label);
            button.setFont(new Font("Arial", Font.BOLD, 18));
            button.setFocusPainted(false);
            button.addActionListener(this);
            gridPanel.add(button);
        }
        add(gridPanel, BorderLayout.CENTER);

        JButton btnHistory = new JButton("View History");
        btnHistory.setFont(new Font("Arial", Font.PLAIN, 14));
        btnHistory.setFocusPainted(false);
        btnHistory.addActionListener(e -> showHistoryDialog());

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(btnHistory);
        add(bottomPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        String currentText = display.getText();

        if (currentText.equals("0") && !command.equals(".") && !isOperator(command)) {
            currentText = "";
        }

        switch (command) {
            case "C":
                display.setText("0");
                break;

            case "=":
                try {
                    String expression = display.getText();
                    double result = evaluateExpression(expression);

                    String resultString = (result % 1 == 0) ? String.valueOf((int) result) : String.valueOf(result);
                    display.setText(resultString);

                    addToHistory(expression + " = " + resultString);

                } catch (Exception ex) {
                    display.setText("Error");
                }
                break;

            default:
                if (currentText.equals("Error")) {
                    currentText = "";
                }
                display.setText(currentText + command);
                break;
        }
    }

    private boolean isOperator(String cmd) {
        return cmd.equals("+") || cmd.equals("-") || cmd.equals("*") || cmd.equals("/") || cmd.equals("%");
    }

    private void addToHistory(String record) {
        if (calculationHistory.size() >= 10) {
            calculationHistory.remove(0); // Remove oldest
        }
        calculationHistory.add(record);
    }

    private void showHistoryDialog() {
        if (calculationHistory.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No calculations performed yet.", "History", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder historyText = new StringBuilder("Last 10 Calculations:\n\n");
        for (int i = 0; i < calculationHistory.size(); i++) {
            historyText.append(i + 1).append(". ").append(calculationHistory.get(i)).append("\n");
        }

        JOptionPane.showMessageDialog(this, historyText.toString(), "Calculation History", JOptionPane.PLAIN_MESSAGE);
    }

    private double evaluateExpression(String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char)ch);
                return x;
            }

            double parseExpression() {
                double x = parseTerm();
                for (;;) {
                    if      (eat('+')) x += parseTerm(); // addition
                    else if (eat('-')) x -= parseTerm(); // subtraction
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (;;) {
                    if      (eat('*')) x *= parseFactor(); // multiplication
                    else if (eat('/')) x /= parseFactor(); // division
                    else if (eat('%')) x %= parseFactor(); // modulo
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor(); // unary plus
                if (eat('-')) return -parseFactor(); // unary minus

                double x;
                int startPos = this.pos;
                if (eat('(')) { // parentheses
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') { // numbers
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else {
                    throw new RuntimeException("Unexpected character");
                }
                return x;
            }
        }.parse();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AdvancedCalculator().setVisible(true);
        });
    }
}
