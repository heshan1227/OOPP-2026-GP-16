package dao;

import model.*;
import util.DBConnection;
import java.sql.*;
import java.util.*;

public class MedicalDAO {
    public void save(MedicalRecord r) throws SQLException {
        String sql="INSERT INTO medical_records (undergraduate_id,course_id,component_type,session_number,absent_date,reference_no,reason,submission_date,status,reviewed_by,certificate_path) SELECT u.undergraduate_id,c.course_id,?,?,?,?,?,?,?,?,? FROM undergraduates u JOIN courses c ON c.course_code=? WHERE u.reg_number=?";
        try(Connection cn=DBConnection.getConnection();PreparedStatement ps=cn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
            ps.setString(1,r.getComponentType().name());ps.setInt(2,r.getSessionNumber());ps.setDate(3,java.sql.Date.valueOf(r.getAbsentDate()));
            ps.setString(4,r.getReferenceNo());ps.setString(5,r.getReason());ps.setDate(6,java.sql.Date.valueOf(r.getSubmissionDate()));
            ps.setString(7,r.getStatus().name());ps.setString(8,r.getReviewedBy());ps.setString(9,r.getCertificatePath());
            ps.setString(10,r.getCourseCode());ps.setString(11,r.getStudentRegNo());
            if(ps.executeUpdate()!=1)throw new SQLException("Student registration number or course code was not found.");
            try(ResultSet keys=ps.getGeneratedKeys()){if(keys.next())r.setMedicalId(keys.getInt(1));}
        }
    }
    public void updateStatus(int id, MedicalStatus status, String reviewer) throws SQLException {
        try(Connection cn=DBConnection.getConnection();PreparedStatement ps=cn.prepareStatement("UPDATE medical_records SET status=?, reviewed_by=?, reviewed_at=CURRENT_TIMESTAMP WHERE medical_id=?")){
            ps.setString(1,status.name());ps.setString(2,reviewer);ps.setInt(3,id);if(ps.executeUpdate()!=1)throw new SQLException("Medical record not found.");
        }
    }
    public List<MedicalRecord> getAll() throws SQLException {
        String sql="SELECT m.medical_id,u.reg_number,usr.name,c.course_code,m.component_type,m.session_number,m.absent_date,m.reference_no,m.reason,m.submission_date,m.status,m.reviewed_by,m.certificate_path FROM medical_records m JOIN undergraduates u ON u.undergraduate_id=m.undergraduate_id JOIN users usr ON usr.user_id=u.user_id JOIN courses c ON c.course_id=m.course_id ORDER BY m.submission_date DESC";
        List<MedicalRecord> out=new ArrayList<>();
        try(Connection cn=DBConnection.getConnection();PreparedStatement ps=cn.prepareStatement(sql);ResultSet rs=ps.executeQuery()){
            while(rs.next())out.add(new MedicalRecord(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),ComponentType.valueOf(rs.getString(5)),rs.getInt(6),rs.getDate(7).toLocalDate(),rs.getString(8),rs.getString(9),rs.getDate(10).toLocalDate(),MedicalStatus.valueOf(rs.getString(11)),rs.getString(12),rs.getString(13)));
        }return out;
    }
}
