package dao;

import model.TimetableEntry;
import util.DBConnection;
import java.sql.*;
import java.time.LocalTime;
import java.util.*;

public class TimetableDAO {
    public List<TimetableEntry> getAll() throws SQLException {
        String sql="SELECT t.timetable_id,c.course_code,c.course_name,t.component_type,t.day_of_week,t.start_time,t.end_time,t.venue,COALESCE(l.name,''),COALESCE(t.department,''),COALESCE(b.batch_name,''),COALESCE(p.period_name,'') FROM timetables t JOIN courses c ON c.course_id=t.course_id LEFT JOIN users l ON l.user_id=t.lecturer_id LEFT JOIN batches b ON b.batch_id=t.batch_id LEFT JOIN academic_periods p ON p.period_id=t.period_id ORDER BY FIELD(t.day_of_week,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'),t.start_time";
        List<TimetableEntry> out=new ArrayList<>();
        try(Connection c=DBConnection.getConnection();PreparedStatement ps=c.prepareStatement(sql);ResultSet r=ps.executeQuery()){
            while(r.next())out.add(new TimetableEntry(r.getInt(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5),r.getTime(6).toLocalTime(),r.getTime(7).toLocalTime(),r.getString(8),r.getString(9),r.getString(10),r.getString(11),r.getString(12)));
        }return out;
    }
    public void save(TimetableEntry t, int courseId, Integer batchId, Integer periodId, Integer lecturerId) throws SQLException {
        String sql="INSERT INTO timetables(course_id,batch_id,period_id,lecturer_id,component_type,day_of_week,start_time,end_time,venue,department) VALUES(?,?,?,?,?,?,?,?,?,?)";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){
            p.setInt(1,courseId);setNullableInt(p,2,batchId);setNullableInt(p,3,periodId);setNullableInt(p,4,lecturerId);
            p.setString(5,t.getComponentType());p.setString(6,t.getDayOfWeek());p.setTime(7,Time.valueOf(t.getStartTime()));p.setTime(8,Time.valueOf(t.getEndTime()));p.setString(9,t.getVenue());p.setString(10,t.getDepartment());p.executeUpdate();
        }
    }
    public void update(TimetableEntry t, int courseId, Integer batchId, Integer periodId, Integer lecturerId) throws SQLException {
        String sql="UPDATE timetables SET course_id=?,batch_id=?,period_id=?,lecturer_id=?,component_type=?,day_of_week=?,start_time=?,end_time=?,venue=?,department=? WHERE timetable_id=?";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){
            p.setInt(1,courseId);setNullableInt(p,2,batchId);setNullableInt(p,3,periodId);setNullableInt(p,4,lecturerId);
            p.setString(5,t.getComponentType());p.setString(6,t.getDayOfWeek());p.setTime(7,Time.valueOf(t.getStartTime()));p.setTime(8,Time.valueOf(t.getEndTime()));p.setString(9,t.getVenue());p.setString(10,t.getDepartment());p.setInt(11,t.getTimetableId());
            if(p.executeUpdate()!=1)throw new SQLException("Timetable entry not found.");
        }
    }
    public void delete(int id) throws SQLException {try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM timetables WHERE timetable_id=?")){p.setInt(1,id);p.executeUpdate();}}
    private void setNullableInt(PreparedStatement p,int index,Integer value)throws SQLException{if(value==null)p.setNull(index,Types.INTEGER);else p.setInt(index,value);}
}
