package dao;

import model.Notice;
import util.DBConnection;
import java.sql.*;
import java.util.*;

public class NoticeDAO {
    public void save(Notice n, int createdBy) throws SQLException {
        String sql="INSERT INTO notices(title,content,created_by,target_role,is_important,published_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
            p.setString(1,n.getTitle());p.setString(2,n.getContent());p.setInt(3,createdBy);
            if(n.getTargetRole()==null||n.getTargetRole().equalsIgnoreCase("ALL"))p.setNull(4,Types.VARCHAR);else p.setString(4,n.getTargetRole().toUpperCase());
            p.setBoolean(5,n.isImportant());p.executeUpdate();try(ResultSet r=p.getGeneratedKeys()){if(r.next())n.setNoticeId(r.getInt(1));}
        }
    }
    public List<Notice> getVisibleForRole(String role) throws SQLException {
        List<Notice> out=new ArrayList<>();
        String sql="SELECT n.notice_id,n.title,n.content,u.name,n.published_at,n.target_role,n.is_important FROM notices n LEFT JOIN users u ON u.user_id=n.created_by WHERE n.target_role IS NULL OR UPPER(n.target_role)='ALL' OR UPPER(n.target_role)=? ORDER BY n.is_important DESC,n.published_at DESC";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){p.setString(1,role.toUpperCase());try(ResultSet r=p.executeQuery()){while(r.next()){Timestamp ts=r.getTimestamp(5);out.add(new Notice(r.getInt(1),r.getString(2),r.getString(3),r.getString(4),ts==null?null:ts.toLocalDateTime(),r.getString(6),r.getBoolean(7)));}}}
        return out;
    }
    public void delete(int id) throws SQLException {try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM notices WHERE notice_id=?")){p.setInt(1,id);p.executeUpdate();}}
}
